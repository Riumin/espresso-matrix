---
layout: posttw
title: "“JOYTOU博客”微信公眾號開通啦"
description: "“JOYTOU博客”公眾號開通"
date: 2017-12-06 03:02:00 +0800
lang: tw
nav: post
stickie: false
category: official
tags: [wechat, joytou]
---

* content
{:toc}


<p>在這裡，你可以隨時的關注到本博客的最新動向。 不用再每天刷著博客，等待又等待。</p>
<p>手指輕輕一點，即可瞭解博客的最新資訊、訪問博客。 只要有任何關於本博客的消息，我們都將第一時間發送給您！</p>
<p>使用者可通過搜索“<b>JOYTOU博客</b>”或“<b>joytouBlog</b>”，或者直接掃描下方二維碼關注！</p>
<img src="{{ '/assets/qrcode_for_gh_fdcd74bd5633_1280.jpg' | prepend: site.baseurl }}" class="img-responsive"/>
