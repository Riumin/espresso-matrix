---
layout: posten
title: "“JOYTOU BLOG”Wechat public account has been published"
description: "“JOYTOU BLOG” Wechat official account has been published"
date: 2017-12-06 03:02:00 +0800
lang: en
nav: post
stickie: false
category: official
tags: [wechat, joytou]
---

* content
{:toc}


<p>In here, you can attention to this blogger's latest Dynamic at any time, and needn't to brush the blog every day, waitting and waitting.</p>
<p>With a little bit of your finger, you can get the latest information about the blog and visit the blog. As long as there is any news about this blog, we will send you in the first time!</p>
<p>Users can search the Wechat official account ID "<b>joytouBlog</b>" or scan the 2d code below!</p>
<img src="{{ '/assets/qrcode_for_gh_fdcd74bd5633_1280.jpg' | prepend: site.baseurl }}" class="img-responsive"/>
